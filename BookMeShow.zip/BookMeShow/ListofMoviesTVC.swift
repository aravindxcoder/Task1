//
//  ListofMoviesTVC.swift
//  BookMeShow
//
//  Created by Aravind Devireddy on 05/09/24.
//

//import UIKit

//class ListofMoviesTVC: UITableViewCell {
//    
//    @IBOutlet weak var movieImages: UIImageView!
//    @IBOutlet weak var movieTitle: UILabel!
//    @IBOutlet weak var releaseDate: UILabel!
//    @IBOutlet weak var type: UILabel!
//    @IBOutlet weak var favoriteBtn: UIButton!
//    
//    private var movie: Movie?
//    
//    var isFavorited = false
//    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//    }
//    
//    func configure(with movie: Movie) {
//            // Set movie title and year (assuming year as release date)
//            movieTitle.text = movie.title
//            releaseDate.text = movie.year
//            type.text = movie.type
//            
//            // Set the image from the poster URL
//            if let url = URL(string: movie.poster) {
//                DispatchQueue.global().async {
//                    if let data = try? Data(contentsOf: url) {
//                        DispatchQueue.main.async {
//                            self.movieImages.image = UIImage(data: data)
//                        }
//                    }
//                }
//            }
//            
//            // Set favorite button to a default state (not favorited)
//            updateFavoriteButton()
//        }
//    
//    private func updateFavoriteButton() {
//        //        if !isFavorited {
//        //            favoriteBtn.setImage(UIImage(named: "non-favorite"), for: .normal)
//        //        } else{
//        //            favoriteBtn.setImage(UIImage(named: "favorite"), for: .normal)
//        //        }
//        guard let movie = movie else { return }
//        let isFavorited = FavoritesManager.shared.isMovieFavorited(movie.imdbID)
//        let imageName = isFavorited ? "favorite" : "non-favorite"
//        favoriteBtn.setImage(UIImage(systemName: imageName), for: .normal)
//        //        let imageName = isFavorited ? "non-favorite" : "favorite" // Use appropriate image names
//        //        favorite.setImage(UIImage(systemName: imageName), for: .normal)
//    }
//    
//    @IBAction func favoriteButtonAction(_ sender: Any) {
//        guard let movie = movie else { return }
//        // Toggle favorite state
//        isFavorited.toggle()
//        if FavoritesManager.shared.isMovieFavorited(movie.imdbID) {
//            FavoritesManager.shared.removeFromFavorites(movie.imdbID)
//        } else {
//            FavoritesManager.shared.addToFavorites(movie.imdbID)
//        }
//        updateFavoriteButton()
//        
//    }
//    
//}
